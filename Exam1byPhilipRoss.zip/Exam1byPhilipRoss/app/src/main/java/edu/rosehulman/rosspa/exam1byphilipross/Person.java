package edu.rosehulman.rosspa.exam1byphilipross;

/**
 * Created by rosspa on 12/13/2016.
 */

public class Person {
}
